#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef _TAREADOR_
#include <tareador.h>
#endif

double getusec_() {
        struct timeval time;
        gettimeofday(&time, NULL);
        return ((double)time.tv_sec * (double)1e6 + (double)time.tv_usec);
}

#define START_COUNT_TIME stamp = getusec_();
#define STOP_COUNT_TIME stamp = getusec_() - stamp;\
                        stamp = stamp/1e6;

// process only odd numbers of a specified block
int eratosthenesBlock(const int from, const int to)
{
  // 1. create a list of natural numbers 2, 3, 4, ... all of them initially marked as potential primes
  const int memorySize = (to - from + 1) / 2; // only odd numbers
  char * isPrime = (char *) malloc((memorySize) * sizeof(char));
  for (int i = 0; i < memorySize; i++) isPrime[i] = 0;

  // 2. Starting from i=3, the first unmarked number on the list ...
  for (int i = 3; i*i <= to; i+=2) {
    // ... find the smallest number greater or equal than i that is unmarked 
    // skip multiples of three: 9, 15, 21, 27, ...
    if (i >= 3*3 && i % 3 == 0)
      continue;
    // skip multiples of five
    if (i >= 5*5 && i % 5 == 0)
      continue;
    // skip multiples of seven
    if (i >= 7*7 && i % 7 == 0)
      continue;
    // skip multiples of eleven
    if (i >= 11*11 && i % 11 == 0)
      continue;
    // skip multiples of thirteen
    if (i >= 13*13 && i % 13 == 0)
      continue;
    // skip numbers before current slice
    int minJ = ((from+i-1)/i)*i;
    if (minJ < i*i) minJ = i*i;
    // start value must be odd
    if ((minJ & 1) == 0) minJ += i;

    // 3. Mark all multiples of i between i^2 and lastNumber
    for (int j = minJ; j <= to; j += 2*i) {
      int index = j - from;
      isPrime[index/2]++;
    }
  }

  // 4. The unmarked numbers are primes, count primes
  int found = 0;
  for (int i = 0; i < memorySize; i++) 
    if (!isPrime[i]) found++;
  // 2 is not odd => include on demand
  if (from <= 2) found++;

  // 5. We are done with the isPrime array, free it
  free(isPrime);
  return found;
}

// process slice-by-slice
int eratosthenes(int lastNumber, int sliceSize)
{
  int found = 0;

  // each slice covers ["from" ... "to"], incl. "from" and "to"
  for (int from = 2; from <= lastNumber; from += sliceSize) {
    int to = from + sliceSize;
    if (to > lastNumber) to = lastNumber;
    found += eratosthenesBlock(from, to);
  }

  return found;
}

void usage(void) {
    printf("sieve <range> <slice_size>\n");
    printf("      <range> is an integer N - the range is from 2 - N\n");
    printf("      <slice_size> is to sieve the list from 2 - N in blocks\n");
}

int main(int argc, char ** argv) {
    // argv[1]: Upper-bound on primes
    // argv[2]: Slice size
    int range_max, slice_size;

    if (argc != 3) {
        range_max = 36;
	slice_size = 4;
    } else {
        range_max = atoi(argv[1]);
        slice_size = atoi(argv[2]);
    }

    if (range_max < 2) {
        printf("Error: <range> Must be an integer greater than or equal to 2\n");
        usage();
        return 0;
    }

    if ((slice_size > range_max) || (slice_size < 2)) {
        printf("Error: <slice_size> Must be an integer greater than or equal to 2 but smaller or equal than range\n");
        usage();
        return 0;
    }

#ifndef _TAREADOR_
    double stamp;
#endif

    // Solutions count

#ifdef _TAREADOR_
    tareador_ON ();
#else
    START_COUNT_TIME;
#endif

    int count = eratosthenes(range_max, slice_size);

#ifdef _TAREADOR_
    tareador_OFF ();
#else
    STOP_COUNT_TIME;
#endif

    // Print the results.
    printf("Number of primes smaller than or equal to %d = %d\n", range_max, count);
#ifndef _TAREADOR_
    printf ("%0.6f\n", stamp);
#endif

    return 0;
}
