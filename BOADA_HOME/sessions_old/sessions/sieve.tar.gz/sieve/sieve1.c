#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef _TAREADOR_
#include <tareador.h>
#endif

double getusec_() {
        struct timeval time;
        gettimeofday(&time, NULL);
        return ((double)time.tv_sec * (double)1e6 + (double)time.tv_usec);
}

#define START_COUNT_TIME stamp = getusec_();
#define STOP_COUNT_TIME stamp = getusec_() - stamp;\
                        stamp = stamp/1e6;

// simple serial sieve of Eratosthenes
int eratosthenes(int lastNumber)
{
  int found = 0;
  int sqrt_lN = sqrt(lastNumber);
  #ifdef _TAREADOR_
  char stringMessage[256];
  #endif

  // 1. create a list of natural numbers 2, 3, 4, ... all of them initially marked as potential primes
  char * isPrime = (char *) malloc((lastNumber+1) * sizeof(char));
  for (int i = 0; i <= lastNumber; i++) {
       #ifdef _TAREADOR_
       sprintf(stringMessage,"init_%d",0);
       tareador_start_task(stringMessage);
       #endif
       isPrime[i] = 0;
       #ifdef _TAREADOR_
       tareador_end_task(stringMessage);
       #endif
  }

  // 2. Starting from i=2, the first unmarked number on the list ...
  for (int i = 2; i <= sqrt_lN; i++)
    // ... find the smallest number greater or equal than i that is unmarked 
    if (!isPrime[i])
      // 3. Mark all multiples of i between i^2 and lastNumber
      #pragma omp parallel for
      for (int j = i*i; j <= lastNumber; j += i) {
          isPrime[j]++;
      }

  // 4. The unmarked numbers are primes, count primes
  #pragma omp parallel for reduction(+:found)
  for (int i = 2; i <= lastNumber; i++) {
	if (!isPrime[i]) found++;
  }

  // 5. We are done with the isPrime array, free it
  free(isPrime);
  return found;
}

void usage(void) {
    printf("sieve <range>\n");
    printf("      <range> is an integer N - the range is from 2 - N\n");
}

int main(int argc, char ** argv) {
    // argv[1]: Upper-bound on primes
    int range_max;

    if (argc != 2) 
        range_max = 36; 
    else
        range_max = atoi(argv[1]);

    if (range_max < 2) {
        printf("Error: <range> Must be an integer greater than or equal to 2\n");
        usage();
        return 0;
    }

#ifndef _TAREADOR_
    double stamp;
#endif

    // Solutions count

#ifdef _TAREADOR_
    tareador_ON ();
#else
    START_COUNT_TIME;
#endif

    int count = eratosthenes(range_max);

#ifdef _TAREADOR_
    tareador_OFF ();
#else
    STOP_COUNT_TIME;
#endif

    // Print the results.
    printf("Number of primes smaller than or equal to %d = %d\n", range_max, count);
#ifndef _TAREADOR_
    printf ("%0.6f\n", stamp);
#endif

    return 0;
}
