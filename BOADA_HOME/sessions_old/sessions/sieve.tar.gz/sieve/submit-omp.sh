#!/bin/bash
### Directives pel gestor de cues
# following option makes sure the job will run in the current directory
#$ -cwd
# following option makes sure the job has the same environmnent variables as the submission shell
#$ -V
# Canviar el nom del job
#$ -N lab1-omp
# Per canviar de shell
#$ -S /bin/bash

USAGE="\n USAGE: ./submit-omp prog range slice_size num_threads\n
        prog        -> omp program name\n
        range       -> count primes between 2 and range\n
        slice_size  -> size of the blocks to sieve (only for sieve2)\n
        num_threads -> number of threads\n"

#Comment/uncomment to handle sieve1 or sieve2 appropriately
if (test $# -lt 3 || test $# -gt 3)
#if (test $# -lt 4 || test $# -gt 4)
then
	echo -e $USAGE
        exit 0
fi

make $1-omp

#Comment/uncomment to handle sieve1 or sieve2 appropriately
export OMP_NUM_THREADS=$3
#export OMP_NUM_THREADS=$4

HOST=$(echo $HOSTNAME | cut -f 1 -d'.')

#Comment/uncomment to handle sieve1 or sieve2 appropriately
/usr/bin/time -o time-$1-$2-$3-${HOST} ./$1-omp $2
#/usr/bin/time -o time-$1-$2-$3-$4-${HOST} ./$1-omp $2 $3
